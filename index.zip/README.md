# Assignment 3 Specifications
The application allows the user to review GitHub public repositories and add the to a list.

All functionality will be evaluated for techniques covered in class and following the specifications. Your application should be identical to the video demo in all aspects. Any functionality that is added outside of material not covered in class will be subject to Academic Policy 1111 violation.

1. Create a **js** folder for your JavaScript files
2. Create the following JavaScript files in the **js** folder
    - app.js
    - dom.js
    - validate.js
    - repo.js
3. In the **dom.js** file, complete the following:
    - Function name **$**
        - Parameters
            - **selector** of type string
        - Returns 
            - Element | NodeListOf<Element>
        - Description
            - Used to query the DOM
            - Using document.querySelectorAll, query the DOM using the proviuded **selector** parameter. Determine if this call returned one or many elements. If list of one element was returned, return that single element, if a list of more than one elements were returned, return the list. Export this function.
    - Function name **cE**
        - Parameters
            - **element** of type string
        - Returns
            - HTMLElement
        - Description
            - Creates an eleement
            - Use the correct method of the document object to create an element using the **element** parameter and return this created element. Export this function.
    - Function name **cT**
        - Parameters
            - **element** of type HTMLELement
            - **value** of type string
        - Returns
            - No return
        - Description
            - Adds a text node to the provided **element** using the provided **value**.
            - Clear the inner html of the provded **element**. Append a text node using the provided **value**. Export this function.
4. In the **validate.js** file, complete the following:
    - Function name **isNumeric**
        - Parameters
            - **value** of type number
        - Returns
            - boolean
        - Description
            - Validates a value is numeric.
            - Validate the **value** parameters is a number and return the result of this check as boolean. Export this function.
    - Function name **isGreaterThanZero**
        - Parameters
            - **value** of type number
        - Returns
            - boolean
        - Description
            - Validates a number is greater than zero
            - Validate the **value** is numeric and greater than zero. Use the **isNumeric** function before checking for value greater than zero. Return true or false at the appropriate logical control flow. Export this function.
    - Function name **isRequired**
        - Parameters
            - **text** as type string
        - Returns
            - boolean
        - Description
            - Validates a string is not null of empty
            - Use a correct technique to check the **text** parameters is not null or an empty string. Export this function.
5. In the **repo.js** file, complete the following:
    - Create a class **Repository** with the following properties:
        - name: The repository name
        - desc: The respository description
        - url: The web url link to the repository
        - rating: The rating from 1 to 5 given to the repository
        - Add these properties with the constructor
        
        - Fuction name **isValidaGithubLink**
            - Paramaters
                - None
            - Returns 
                - boolean
            - Description
                - Validates the **url** property is a valid url from **https://github.com**
    - Export this class
6. Add a reference to **app.js** in the **index.html**. The script reference must be in the head tag. Ensure this script is configured to allow the DOM to load before the script is executed. Ensure the script allows supports module JavaScript.
7. In the **app.js** file, complete the following:
    - Imports
        - Import all **dom.js** functions
        - Import the **Repository** class from **repo.js**
        - Import all **validate.js** functions

    - Create an **errors** array to hold validation errors.
    - Query the DOM using the proper function you created in a prevous module. You do not use any document methods.
    - Query the DOM for the form and store in constant **form**
    - Query the DOM for the id **repoList**
    - Query the DOM for the id **errorList**

    - Functions as arrow functions
        - **clearErrors**
            - Parameters
                - None
            - Description
                - Clears validation errors from the HTML
                - Clears the **errors** array
                - Clears the html of **errorList**
                - Adds the **hide** class to **errorList**
        - **displayErrors**
            - Parameters
                - None
            -Description
                - Displays validation errors on the HTML page
                - Loop the errors and complete the following
                    - Create an **li** using the **cE** function
                    - Add the error to the **li** using the **cT** function
                    - Append the **li** to the **errorList**
                - Remove the class **hide** from **errorList**
        - **addRepo**
            - Parameters
                - **repo** of type **Repository**
            - Returns
                - No return
            - Description
                - Adds the repository to a to a list of reviewed repositories on the HTML page.
                - Create a **div** tag using **cE** stoed in a variable called **nameDiv**.
                - Create a **div** tag using **cE** stoed in a variable called **descDiv**.
                - Create a **div** tag using **cE** stoed in a variable called **rating**.
                - Create an **a** tag using **cE** stoed in a variable called **a**.
                - Add the **mt-30** class to the **nameDiv**.
                - In the **a** element 
                    - Add the **repo** class
                    - Set the **href** attribute to the **repo** parameter **url** property.
                    - Set the **target** attribute to **_blank**.
                    - Add a text node using **cT** to the **repo** parameter **name** property.
                    - Append **a** as a child to **nameDiv**.
                - Add a text node to **descDiv** using **cT** to the **repo** parameter **desc** property.
                - Using the **repo.rating** property, use a loop to append the ratings stars using a Font Awesome icon of classes **fa-regular fa-star**. Append the stars to the **rating** element.
                - Append the **nameDiv** as a child to **repoList**
                - Append the **descDiv** as a child to **repoList**
                - Append the **rating** as a child to **repoList**
        - **isValidRepo**
             - Parameters
                - **repo** of type **Repository**
            - Returns
                - boolean
            - Description
                - Validates a **Repository** class instance.
                - Add errors to the **errors** array for the following function calls if the function call returns false. Set the error messages accordingly as shown in the video:
                    - The **repo** parameter's **isValidGithubLink** function
                    - The **isRequired** using the **repo.name** property
                    - The **minLength** using the **repo.desc** property. Minimum length of the **desc** is **10**
                    - The **isNumeric** 
                - Return the result of validation by using the **errors**
 8. Handle the **form** submission event and complete the following in an anonymous arrow function:
    - Clear the errors with the appropriate function we created.
    - Stop the default behavior of form submission.
    - Create an instance of a Repository class and store in a constant called **repo**. Pass in the required values in the constructor.
    - Use the **isValidRepo** function correctly to validate the **repo** **Repository** instance. When valid, use the **addRepo** function correctly to display the Repository clas instance on the HTML page.
    - Reset the form.
    - If the **repo** class instance is not valid, display the errors using the appropriate function.


    